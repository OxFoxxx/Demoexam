"""Desktop-приложение (Tkinter): авторизация, список товаров, добавление/редактирование."""
from __future__ import annotations

import shutil
import tkinter as tk
from decimal import Decimal, InvalidOperation
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import Image, ImageDraw, ImageTk

from data import (InMemoryRepository, Product, ROLE_ADMIN, ROLE_CLIENT, ROLE_GUEST,
                  ROLE_MANAGER, User, filter_and_sort)

BASE = Path(__file__).resolve().parent
IMAGES_DIR = BASE / "images"
PLACEHOLDER = BASE / "resources" / "picture.png"
ALL_LABEL = "Все производители"
SORT_OPTIONS = {"Без сортировки": "", "Цена по возрастанию": "asc", "Цена по убыванию": "desc"}
ROLE_NAMES = {ROLE_GUEST: "Гость", ROLE_CLIENT: "Клиент", ROLE_MANAGER: "Менеджер", ROLE_ADMIN: "Администратор"}
THUMB = (110, 85)


def ensure_placeholder() -> None:
    """picture.png должен лежать в ресурсах; если его нет — создаём простую заглушку."""
    if PLACEHOLDER.exists():
        return
    PLACEHOLDER.parent.mkdir(parents=True, exist_ok=True)
    img = Image.new("RGB", (300, 230), "#e4e4e4")
    d = ImageDraw.Draw(img)
    d.rectangle((100, 70, 200, 160), outline="#9a9a9a", width=4)
    d.text((118, 105), "Нет фото", fill="#7a7a7a")
    img.save(PLACEHOLDER)


class ImageCache:
    def __init__(self) -> None:
        self._cache: dict[str, ImageTk.PhotoImage] = {}

    def get(self, filename: str) -> ImageTk.PhotoImage:
        path = IMAGES_DIR / filename if filename else PLACEHOLDER
        if not path.is_file():
            path = PLACEHOLDER
        key = str(path)
        if key not in self._cache:
            img = Image.open(path).convert("RGB")
            img.thumbnail(THUMB)
            self._cache[key] = ImageTk.PhotoImage(img)
        return self._cache[key]

    def drop(self) -> None:
        self._cache.clear()


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Учёт товаров")
        self.geometry("980x680")
        self.minsize(820, 520)
        ensure_placeholder()
        IMAGES_DIR.mkdir(exist_ok=True)
        self.repo = InMemoryRepository()
        self.images = ImageCache()
        self.user: User | None = None
        self._frame: tk.Frame | None = None
        self.show_login()

    def _switch(self, frame: tk.Frame) -> None:
        if self._frame is not None:
            self._frame.destroy()
        self._frame = frame
        frame.pack(fill="both", expand=True)

    def show_login(self) -> None:
        self.user = None
        self._switch(LoginFrame(self))

    def login_as(self, user: User) -> None:
        self.user = user
        self._switch(ProductListFrame(self))


class LoginFrame(ttk.Frame):
    def __init__(self, app: App) -> None:
        super().__init__(app, padding=20)
        self.app = app
        box = ttk.Frame(self)
        box.place(relx=0.5, rely=0.45, anchor="center")
        ttk.Label(box, text="Вход в систему", font=("Segoe UI", 18, "bold")).grid(row=0, column=0, columnspan=2, pady=(0, 18))
        ttk.Label(box, text="Логин:").grid(row=1, column=0, sticky="e", pady=4, padx=(0, 8))
        ttk.Label(box, text="Пароль:").grid(row=2, column=0, sticky="e", pady=4, padx=(0, 8))
        self.login_var, self.pass_var = tk.StringVar(), tk.StringVar()
        self.login_entry = ttk.Entry(box, textvariable=self.login_var, width=28)
        self.pass_entry = ttk.Entry(box, textvariable=self.pass_var, show="•", width=28)
        self.login_entry.grid(row=1, column=1, pady=4)
        self.pass_entry.grid(row=2, column=1, pady=4)
        self.error = ttk.Label(box, text="", foreground="#c0392b")
        self.error.grid(row=3, column=0, columnspan=2, pady=(6, 0))
        ttk.Button(box, text="Войти", command=self.submit).grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 4))
        ttk.Button(box, text="Войти как гость", command=self.guest).grid(row=5, column=0, columnspan=2, sticky="ew")
        self.login_entry.focus_set()
        for w in (self.login_entry, self.pass_entry):
            w.bind("<Return>", lambda e: self.submit())

    def submit(self) -> None:
        login, password = self.login_var.get().strip(), self.pass_var.get()
        if not login or not password:
            self.error.config(text="Введите логин и пароль")
            return
        user = self.app.repo.authenticate(login, password)
        if user is None:
            self.error.config(text="Неверный логин или пароль")
            self.pass_var.set("")
            return
        self.app.login_as(user)

    def guest(self) -> None:
        self.app.login_as(User("", "", "Гость", ROLE_GUEST))


class ProductListFrame(ttk.Frame):
    def __init__(self, app: App) -> None:
        super().__init__(app)
        self.app = app
        self.repo = app.repo
        self.is_admin = app.user.role == ROLE_ADMIN

        top = ttk.Frame(self, padding=(12, 10))
        top.pack(fill="x")
        ttk.Label(top, text="Товары", font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Button(top, text="Выйти", command=app.show_login).pack(side="right")
        ttk.Label(top, text=app.user.full_name, font=("Segoe UI", 11)).pack(side="right", padx=12)

        bar = ttk.Frame(self, padding=(12, 0, 12, 8))
        bar.pack(fill="x")
        self.search_var = tk.StringVar()
        self.sort_var = tk.StringVar(value="Без сортировки")
        self.man_var = tk.StringVar(value=ALL_LABEL)
        ttk.Label(bar, text="Поиск:").pack(side="left")
        ttk.Entry(bar, textvariable=self.search_var, width=30).pack(side="left", padx=(4, 12))
        self.sort_box = ttk.Combobox(bar, textvariable=self.sort_var, values=list(SORT_OPTIONS), state="readonly", width=22)
        self.sort_box.pack(side="left", padx=(0, 12))
        self.man_box = ttk.Combobox(bar, textvariable=self.man_var, state="readonly", width=24)
        self.man_box.pack(side="left")
        if self.is_admin:
            ttk.Button(bar, text="Добавить товар", command=self.add).pack(side="right")
        self.count_label = ttk.Label(bar, text="")
        self.count_label.pack(side="right", padx=12)

        # Поиск, сортировка и фильтр срабатывают сразу при изменении
        self.search_var.trace_add("write", lambda *_: self.refresh())
        self.sort_box.bind("<<ComboboxSelected>>", lambda e: self.refresh())
        self.man_box.bind("<<ComboboxSelected>>", lambda e: self.refresh())

        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self.canvas = tk.Canvas(wrap, highlightthickness=0, bg="#ffffff")
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(self.canvas, bg="#ffffff")
        self.win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", lambda e: self.canvas.yview_scroll(-2, "units"))
        self.canvas.bind_all("<Button-5>", lambda e: self.canvas.yview_scroll(2, "units"))

        self.refresh_manufacturers()
        self.refresh()

    def destroy(self) -> None:
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.canvas.unbind_all(seq)
        super().destroy()

    def _wheel(self, e) -> None:
        self.canvas.yview_scroll(-1 * (e.delta // 120 if abs(e.delta) >= 120 else (1 if e.delta > 0 else -1)), "units")

    def refresh_manufacturers(self) -> None:
        values = [ALL_LABEL] + self.repo.manufacturers()
        self.man_box["values"] = values
        if self.man_var.get() not in values:
            self.man_var.set(ALL_LABEL)

    def refresh(self) -> None:
        all_products = self.repo.get_products()
        shown = filter_and_sort(all_products, self.search_var.get(), self.man_var.get(),
                                SORT_OPTIONS[self.sort_var.get()], ALL_LABEL)
        self.count_label.config(text=f"{len(shown)} из {len(all_products)}")
        for w in self.inner.winfo_children():
            w.destroy()
        if not shown:
            tk.Label(self.inner, text="Ничего не найдено", bg="#ffffff", fg="#777", pady=30).pack()
        for p in shown:
            self._row(p)
        self.canvas.yview_moveto(0)

    def _row(self, p: Product) -> None:
        row = tk.Frame(self.inner, bg="#ffffff", highlightbackground="#c8c8c8", highlightthickness=1)
        row.pack(fill="x", padx=4, pady=4)
        photo = self.app.images.get(p.image)
        pic = tk.Label(row, image=photo, bg="#ffffff")
        pic.grid(row=0, column=0, rowspan=2, padx=10, pady=8)
        info = tk.Frame(row, bg="#ffffff")
        info.grid(row=0, column=1, sticky="nsew", pady=8)
        stock = tk.Frame(row, bg="#ffffff")
        stock.grid(row=0, column=2, padx=14, pady=8, sticky="ne")
        row.grid_columnconfigure(1, weight=1)

        tk.Label(info, text=p.name, font=("Segoe UI", 12, "bold"), bg="#ffffff", anchor="w").pack(fill="x")
        desc = tk.Label(info, text=p.description, bg="#ffffff", anchor="w", justify="left", wraplength=520)
        desc.pack(fill="x")
        tk.Label(info, text=f"Производитель: {p.manufacturer}", bg="#ffffff", anchor="w").pack(fill="x")
        tk.Label(info, text=f"Цена: {p.price:.2f} ₽", bg="#ffffff", anchor="w").pack(fill="x")
        tk.Label(stock, text="Наличие на складе", bg="#ffffff", fg="#555").pack(anchor="e")
        tk.Label(stock, text=f"{p.quantity} {p.unit}", font=("Segoe UI", 12, "bold"), bg="#ffffff").pack(anchor="e")
        if self.is_admin:
            ttk.Button(stock, text="Удалить", command=lambda pid=p.id: self.delete(pid)).pack(anchor="e", pady=(8, 0))
            self._bind_click(row, lambda e, pid=p.id: self.edit(pid))

    def _bind_click(self, widget, handler) -> None:
        if not isinstance(widget, (ttk.Button, tk.Button)):
            widget.bind("<Button-1>", handler)
            widget.configure(cursor="hand2") if isinstance(widget, (tk.Frame, tk.Label)) else None
        for child in widget.winfo_children():
            self._bind_click(child, handler)

    # --- действия администратора ---
    def add(self) -> None:
        self._open_editor(None)

    def edit(self, product_id: int) -> None:
        product = self.repo.get_product(product_id)
        if product is not None:
            self._open_editor(product)

    def _open_editor(self, product: Product | None) -> None:
        dlg = ProductEditWindow(self.app, product)
        self.wait_window(dlg)
        self.app.images.drop()
        self.refresh_manufacturers()
        self.refresh()

    def delete(self, product_id: int) -> None:
        p = self.repo.get_product(product_id)
        if p is None or not messagebox.askyesno("Удаление", f"Удалить товар «{p.name}»?", parent=self.app):
            return
        ok, msg = self.repo.delete_product(product_id)
        if not ok:
            messagebox.showwarning("Удаление невозможно", msg, parent=self.app)
        self.refresh_manufacturers()
        self.refresh()


class ProductEditWindow(tk.Toplevel):
    def __init__(self, app: App, product: Product | None) -> None:
        super().__init__(app)
        self.app, self.repo = app, app.repo
        self.product = product
        self.title("Редактирование товара" if product else "Добавление товара")
        self.resizable(False, False)
        self.transient(app)
        self.grab_set()

        pad = {"padx": 8, "pady": 4}
        f = ttk.Frame(self, padding=14)
        f.pack(fill="both", expand=True)
        r = 0
        self.vars = {k: tk.StringVar() for k in ("id", "name", "category", "quantity", "unit",
                                                  "supplier", "manufacturer", "price", "image")}

        if product is not None:  # ID показываем только при редактировании, только для чтения
            ttk.Label(f, text="ID:").grid(row=r, column=0, sticky="e", **pad)
            ttk.Entry(f, textvariable=self.vars["id"], state="readonly", width=12).grid(row=r, column=1, sticky="w", **pad)
            r += 1

        def entry(label, key, width=40):
            nonlocal r
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="e", **pad)
            e = ttk.Entry(f, textvariable=self.vars[key], width=width)
            e.grid(row=r, column=1, sticky="w", **pad)
            r += 1
            return e

        def combo(label, key, values):
            nonlocal r
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="e", **pad)
            c = ttk.Combobox(f, textvariable=self.vars[key], values=values, state="readonly", width=37)
            c.grid(row=r, column=1, sticky="w", **pad)
            r += 1

        entry("Наименование:", "name")
        combo("Категория:", "category", self.repo.categories())
        entry("Количество на складе:", "quantity", 14)
        combo("Единица измерения:", "unit", self.repo.units())
        entry("Поставщик:", "supplier")
        entry("Производитель:", "manufacturer")
        entry("Стоимость за единицу:", "price", 14)

        ttk.Label(f, text="Изображение:").grid(row=r, column=0, sticky="e", **pad)
        img_row = ttk.Frame(f)
        img_row.grid(row=r, column=1, sticky="w", **pad)
        self.preview = ttk.Label(img_row)
        self.preview.pack(side="left")
        col = ttk.Frame(img_row)
        col.pack(side="left", padx=8)
        ttk.Button(col, text="Выбрать…", command=self.choose_image).pack(anchor="w")
        ttk.Button(col, text="Убрать", command=self.clear_image).pack(anchor="w", pady=(4, 0))
        r += 1

        ttk.Label(f, text="Описание:").grid(row=r, column=0, sticky="ne", **pad)
        self.desc = tk.Text(f, width=42, height=5, wrap="word")
        self.desc.grid(row=r, column=1, sticky="w", **pad)
        r += 1

        btns = ttk.Frame(f)
        btns.grid(row=r, column=0, columnspan=2, pady=(10, 0), sticky="e")
        ttk.Button(btns, text="Сохранить", command=self.save).pack(side="left", padx=4)
        ttk.Button(btns, text="Отмена", command=self.destroy).pack(side="left")

        if product is not None:  # подгружаем все поля выбранного товара
            v = self.vars
            v["id"].set(str(product.id))
            v["name"].set(product.name)
            v["category"].set(product.category)
            v["quantity"].set(str(product.quantity))
            v["unit"].set(product.unit)
            v["supplier"].set(product.supplier)
            v["manufacturer"].set(product.manufacturer)
            v["price"].set(f"{product.price:.2f}")
            v["image"].set(product.image)
            self.desc.insert("1.0", product.description)
        self.update_preview()

    def update_preview(self) -> None:
        self._photo = self.app.images.get(self.vars["image"].get())
        self.preview.configure(image=self._photo)

    def choose_image(self) -> None:
        path = filedialog.askopenfilename(parent=self, title="Выберите изображение",
                                          filetypes=[("Изображения", "*.png *.jpg *.jpeg *.gif *.bmp"), ("Все файлы", "*.*")])
        if not path:
            return
        src = Path(path)
        dst = IMAGES_DIR / src.name
        if src.resolve() != dst.resolve():
            shutil.copy2(src, dst)
        self.app.images.drop()
        self.vars["image"].set(dst.name)
        self.update_preview()

    def clear_image(self) -> None:
        self.vars["image"].set("")
        self.update_preview()

    def _error(self, msg: str) -> None:
        messagebox.showerror("Ошибка ввода", msg, parent=self)

    def save(self) -> None:
        v = {k: var.get().strip() for k, var in self.vars.items()}
        description = self.desc.get("1.0", "end").strip()
        if not v["name"]:
            return self._error("Укажите наименование товара.")
        if not v["category"]:
            return self._error("Выберите категорию.")
        if not v["unit"]:
            return self._error("Выберите единицу измерения.")
        try:
            quantity = int(v["quantity"])
        except ValueError:
            return self._error("Количество на складе должно быть целым числом.")
        if quantity < 0:
            return self._error("Количество на складе не может быть отрицательным.")
        try:
            price = Decimal(v["price"].replace(",", "."))
            if not price.is_finite():
                raise InvalidOperation
        except InvalidOperation:
            return self._error("Стоимость должна быть числом (можно с сотыми долями).")
        if price < 0:
            return self._error("Стоимость не может быть отрицательной.")
        if price != price.quantize(Decimal("0.01")):
            return self._error("Стоимость указывается с точностью до сотых (2 знака после запятой).")
        price = price.quantize(Decimal("0.01"))

        data = dict(name=v["name"], category=v["category"], description=description,
                    manufacturer=v["manufacturer"], supplier=v["supplier"], price=price,
                    quantity=quantity, unit=v["unit"], image=v["image"])
        if self.product is None:
            self.repo.add_product(Product(id=0, **data))   # id = max(id) + 1 назначает репозиторий
        else:
            self.repo.update_product(Product(id=self.product.id, parent_id=self.product.parent_id, **data))
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
