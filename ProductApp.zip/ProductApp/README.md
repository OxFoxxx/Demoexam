# Учёт товаров (Tkinter)

Запуск: `pip install -r requirements.txt`, затем `python app.py` (нужен Python 3.10+ с Tkinter).

Тестовые учётные записи: admin/admin (администратор), manager/manager (менеджер), client/client (клиент),
плюс кнопка «Войти как гость».

Данные хранятся в памяти (`data.py`, класс `InMemoryRepository`). Для подключения БД реализуйте
класс с теми же методами (authenticate, get_products, add_product, update_product, delete_product,
categories, units, manufacturers, next_id) и подставьте его в `App.__init__`.
Заглушка picture.png лежит в `resources/` (замените своей из ресурсов заказчика).
