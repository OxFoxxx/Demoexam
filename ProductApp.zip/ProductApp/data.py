"""Слой данных. Сейчас — хранилище в памяти.

Позже InMemoryRepository можно заменить на класс с тем же набором методов,
работающий с MS SQL / MySQL (pyodbc, mysql-connector), интерфейс приложения менять не придётся.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

ROLE_GUEST = "guest"
ROLE_CLIENT = "client"
ROLE_MANAGER = "manager"
ROLE_ADMIN = "admin"


@dataclass
class User:
    login: str
    password: str
    full_name: str
    role: str


@dataclass
class Product:
    id: int
    name: str
    category: str
    description: str
    manufacturer: str
    supplier: str
    price: Decimal
    quantity: int
    unit: str
    image: str = ""              # имя файла в папке images/ (пусто -> заглушка)
    parent_id: Optional[int] = None  # не None -> это дополнительный товар другого товара

    def clone(self) -> "Product":
        return copy.deepcopy(self)

    def search_text(self) -> str:
        """Все доступные данные товара одной строкой для поиска."""
        parts = [self.id, self.name, self.category, self.description, self.manufacturer,
                 self.supplier, f"{self.price:.2f}", self.quantity, self.unit]
        return " ".join(str(p) for p in parts).lower()


class InMemoryRepository:
    def __init__(self) -> None:
        self._users = [
            User("admin", "admin", "Иванов Иван Иванович", ROLE_ADMIN),
            User("manager", "manager", "Петрова Анна Сергеевна", ROLE_MANAGER),
            User("client", "client", "Сидоров Пётр Николаевич", ROLE_CLIENT),
        ]
        D = Decimal
        self._products = [
            Product(1, "Мука пшеничная в/с", "Мука", "Мука высшего сорта для выпечки", "Мелькомбинат", "АгроСнаб", D("42.50"), 1200, "кг"),
            Product(2, "Мука ржаная", "Мука", "Обдирная ржаная мука", "Мелькомбинат", "АгроСнаб", D("38.00"), 640, "кг", parent_id=1),
            Product(3, "Сахар-песок", "Сахар", "Сахар белый кристаллический", "Сладкий мир", "ТрейдПартнёр", D("61.90"), 900, "кг"),
            Product(4, "Дрожжи сухие", "Добавки", "Быстродействующие дрожжи, пачка 100 г", "ФерментПлюс", "ХимТорг", D("15.00"), 300, "шт"),
            Product(5, "Соль поваренная", "Добавки", "Соль пищевая, помол №1", "Солевой завод", "АгроСнаб", D("12.30"), 2000, "кг"),
            Product(6, "Масло сливочное 82%", "Молочные", "Сливочное масло, брикет 180 г", "Молочная ферма", "ТрейдПартнёр", D("135.00"), 150, "шт"),
            Product(7, "Яйцо куриное С1", "Яйца", "Яйцо столовое первой категории", "Птицефабрика", "АгроСнаб", D("9.80"), 3000, "шт"),
            Product(8, "Ванилин", "Добавки", "Ванилин пищевой, пакет 2 г", "ФерментПлюс", "ХимТорг", D("4.20"), 500, "шт", parent_id=4),
        ]
        self._categories = ["Мука", "Сахар", "Добавки", "Молочные", "Яйца"]
        self._units = ["кг", "шт", "л", "г"]
        # id товаров, присутствующих в заказах (заглушка вместо таблицы заказов)
        self._ordered_ids = {3, 7}

    # --- пользователи ---
    def authenticate(self, login: str, password: str) -> Optional[User]:
        for u in self._users:
            if u.login == login and u.password == password:
                return u
        return None

    # --- справочники ---
    def categories(self) -> list[str]:
        return sorted(set(self._categories) | {p.category for p in self._products})

    def units(self) -> list[str]:
        return sorted(set(self._units) | {p.unit for p in self._products})

    def manufacturers(self) -> list[str]:
        return sorted({p.manufacturer for p in self._products if p.manufacturer})

    # --- товары ---
    def get_products(self) -> list[Product]:
        return [p.clone() for p in self._products]

    def get_product(self, product_id: int) -> Optional[Product]:
        for p in self._products:
            if p.id == product_id:
                return p.clone()
        return None

    def next_id(self) -> int:
        return max((p.id for p in self._products), default=0) + 1

    def add_product(self, product: Product) -> Product:
        product.id = self.next_id()
        self._products.append(product.clone())
        return product

    def update_product(self, product: Product) -> None:
        for i, p in enumerate(self._products):
            if p.id == product.id:
                self._products[i] = product.clone()
                return
        raise KeyError(product.id)

    def _with_children(self, product_id: int) -> set[int]:
        ids, stack = set(), [product_id]
        while stack:
            cur = stack.pop()
            if cur in ids:
                continue
            ids.add(cur)
            stack.extend(p.id for p in self._products if p.parent_id == cur)
        return ids

    def delete_product(self, product_id: int) -> tuple[bool, str]:
        """Товар нельзя удалить, если он (или его доп. товар) есть в заказе.
        Иначе удаляется вместе с дополнительными товарами."""
        ids = self._with_children(product_id)
        if ids & self._ordered_ids:
            return False, "Товар (или его дополнительный товар) присутствует в заказе — удаление невозможно."
        self._products = [p for p in self._products if p.id not in ids]
        return True, ""


def filter_and_sort(products, query: str, manufacturer: str, sort_mode: str,
                    all_label: str = "Все производители"):
    """Поиск по всем атрибутам (каждое слово запроса должно встретиться где-либо),
    фильтр по производителю и сортировка по цене."""
    words = query.lower().split()
    result = []
    for p in products:
        if manufacturer and manufacturer != all_label and p.manufacturer != manufacturer:
            continue
        text = p.search_text()
        if all(w in text for w in words):
            result.append(p)
    if sort_mode == "asc":
        result.sort(key=lambda p: p.price)
    elif sort_mode == "desc":
        result.sort(key=lambda p: p.price, reverse=True)
    return result
